```html
<div class="notices yellow">
<p>This is a warning notification</p>
</div>
<div class="notices red">
<p>This is a error notification</p>
</div>
<div class="notices blue">
<p>This is a default notification</p>
</div>
<div class="notices green">
<p>This is a success notification</p>
</div>```